import pymysql

pymysql.version_info = (1, 7, 13, "final", 0)

pymysql.install_as_MySQLdb()