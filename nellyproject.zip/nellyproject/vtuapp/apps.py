from django.apps import AppConfig


class VtuappConfig(AppConfig):
    name = 'vtuapp'
